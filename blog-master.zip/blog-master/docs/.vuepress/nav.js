module.exports = [
  {
    "text": "stm32",
    "items": [
      {
        "text": "Stm32",
        "link": "/stm32/"
      }
    ]
  }
];